## Kext reference


#### Lilu.kext

v1.6.9 |
[Sources](https://github.com/acidanthera/Lilu)

#### NVMeFix.kext

v1.1.1 |

[Sources](https://github.com/acidanthera/NVMeFix)

#### VirtualSMC.kext

v1.3.4 |
[Sources](https://github.com/acidanthera/VirtualSMC)

- SMCProcessor.kext
- SMCSuperIO.kext

#### AppleALC.kext

v1.9.2 |
[Sources](https://github.com/acidanthera/AppleALC)

#### WhateverGreen.kext

v1.6.8 |
[Sources](https://github.com/acidanthera/WhateverGreen)

#### IntelMausi.kext

v1.0.7 |
[Sources](https://github.com/acidanthera/IntelMausi)

#### USBPorts.kext

CUSTOM

